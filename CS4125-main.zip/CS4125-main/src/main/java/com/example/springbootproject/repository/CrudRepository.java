package com.example.springbootproject.repository;

public interface CrudRepository<T1, T2> {

}
