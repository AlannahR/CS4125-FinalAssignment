package com.springbootattempt.springbootattempt1;

import java.util.List;

@Component
public class CartDAO {
    
    public List<Book> getAllBooks();
    public Book getBook(int bookId);
    pubilc 

}




