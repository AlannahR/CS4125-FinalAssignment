package com.springbootattempt.springbootattempt1;

public interface CrudRepository<T1, T2> {

}
